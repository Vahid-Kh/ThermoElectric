#!/usr/bin/env python3

'''
Created on 24.12.2009

@author: jm
'''
from softcheck.logic import Com
from softcheck.logic import CommunicationTimeout
import time
import sys


def script():

    #create a Com object with following parameters:
    # serial communication, timeout = 2.3 seconds, explain what's wrong, don't abort program on error 
    com = Com("serial", 2.1)
    # ethernet communication, timeout = 2.3 seconds, explain what's wrong, don't abort program on error
    #com = Com("ethernet", 2.3, True, True)
    com.open('/dev/ttyS0', 9600) #open COM1 with 9600 (address not defined)
    #com.open('/dev/ttyACM0', 9600)
    #com.open("192.168.0.126", 8101) #open ethernet port
    
    while 1:
        try:
            # Ask for the internal temperature and print out the answer
            print("")    
            print("Request T internal and print the answer.")
            com.send("TI?\r\n")
            com.print_answer()
            
            # Ask for the internal temperature and check the first four chars
            print("")
            print("Request T internal and check the first 4 characters.")
            print("An output only occurs if there is an error.")
            com.send("TI?\r\n")
            com.check("TI +") 
          
            # Ask for the internal temperature and check the answer with regex
            # A Message is only shown on an error
            print("")
            print("Request T internal and check the answer with a regular expression.")
            print("The first 5 characters must be \"TI+ <Ziffer>\".")
            print("An output only occurs if there is an error.")
            com.send("TI?\r\n")
            com.check_regex(r"TI +[0-9]*")
            
            # Ask for the internal temperature and print out a formatted string as answer
            print("")
            print("Request T internal and print the answer along with other information.")
            com.send("TI?\r\n")
            Antwort = com.recv()
            Antwort = Antwort[:-2]
            print((Antwort + " has been received."))
            
            time.sleep(5)
        
        except(AssertionError, CommunicationTimeout):
            pass
            
        except:
            print("runtime:", com.get_runtime())
            print("min runtime:", com.get_min_runtime())
            print("max runtime:", com.get_max_runtime())
            print("avg runtime:", com.get_avg_runtime())
            print("std deviation of runtime:", com.get_std_deviation())
            
            print("nr answers:", com.get_nr_answers())
            print("nr commands sent:", com.get_nr_cmds_sent())
            print("nr timeouts:", com.get_nr_timeouts())
            print("nr faulty answers:", com.get_nr_faulty_answers())
            
            com.close()

            sys.exit(0)
        
    com.close()
    
script()

#Examples:
#===========
#    send("[M01V07C6\r")
#    check("[S01V")
#    send("[M01F07B6\r")
#    check("[S01F")
#    send("TI?\r\n")
#    print_answer()
#    time.sleep(0.2)
#    send("[M01L0F********1B\r")
#    check("[S01L")
#    time.sleep(0.1)
#    send("[M01V07C6\r")
#    check("[S01V")
#    send("[M01G0D******\r")
#    print_answer()
#    send("[M01L0F********\r")
#    check("[S01L17******************\r")
#    send("INTERN?\r\n")
#    print_answer()
#    send("SP?\r\n")
#    print_answer()
#   send "Tproz abfragen"
#    send("IN_SP_00\r\n")
#    print_answer()
#    send("OUT_SP_00 3123\r\n")
#    print_answer()
#    send("SP?\r\n")
#    print_answer()
#    send("EXTERN?\r\n")
#    print_answer()
#    send("TI?\r\n")
#    check("TI ")
#    send("WGATE_UPTIME?\r\n")
#    print("Answer: ", recv())
#    send("Ti?\r\n")
#    check("TI ")




    
