#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 13.10.2015

@author: cro
"""
 
import sys
from softcheck.logic import Com
from softcheck.logic import ComBase
from softcheck.conversion import Hex


class MbCom(ComBase):
    """class for handling Modbus commands"""

    def __init__(self, com, protocol_mode="tcp", verbose_level=1, exception_on_error=True):
        """
        @brief constructor for MbCom object
        @param com: Com object that has to be used for communication with the interface
        @param protocol_mode: is 'tcp'
        @param verbose_level: explains what is done:
                                '1': explains what went wrong in case of an error
                                '2': prints the sent and received string on the console
                                '3': prints the time on sending and receiving strings also
        @param exception_on_error: if an error occurs, should the program terminate/throw an exception? 
        """
        ComBase.__init__(self)        
        self._exception_on_error = exception_on_error
        self._verbose_level = verbose_level
        self._isTCP = False
        if isinstance(com, Com):
            self._com = com
        else:
            raise TypeError("The given object is not a Com object. You must provide a Com object that controls the interface")
        if protocol_mode == "tcp":
            self._isTCP = True
        else:
            raise AttributeError("The given protocol_mode is invalid. You must provide a valid protocol_mode")

    @staticmethod
    def int2hex(value, nr_bytes):
        """converts a value to a MB hex string (without 0x and leading zeros)"""
        if type(value) is not int:
            raise TypeError("value must be an integer")
        string = Hex.int2hex(value, nr_bytes * 8)
        string = string[2:]
        length = len(string)
        len_to_add = (nr_bytes * 2) - length
        if len_to_add < 0:
            len_to_add = 0
        for i in range(0, len_to_add):  # IGNORE:W0612
            string = "0" + string
        
        return str.upper(string)
    
    @staticmethod
    def hex2int(string, signed=True):
        """converts a MB hex string (value) to an integer"""
        if type(string) is not str:
            raise TypeError("string must be a string")
        value = Hex.hex2int(string, len(string) * 4, signed)    # (len(string) / 2 * 8)
            
        return value   
    
    def command_to_send(self, tid, pid, uid, fc, pb_addr=None, value=None):
        """returns the command to send as a hex-string"""
        tid_str = self.int2hex(tid, 2)
        pid_str = self.int2hex(pid, 2)
        uid_str = self.int2hex(uid, 1)
        fc_str = self.int2hex(fc, 1)
        
        if value is None:
            if pb_addr is None:
                length = len(bytes([uid])) + len(bytes([fc]))
                length = self.int2hex(length, 2)
                cmd = r'' + tid_str + pid_str + length + uid_str + fc_str 
            else:
                length = len(bytes([uid])) + len(bytes([fc])) + len(bytes([pb_addr]))
                length = self.int2hex(length, 2)
                pb_addr_str = self.int2hex(pb_addr, 1)
                cmd = r'' + tid_str + pid_str + length + uid_str + fc_str + pb_addr_str
        else:
            length = len(bytes([uid])) + len(bytes([fc])) + len(bytes([pb_addr])) + int(len(value)/2)
            length = self.int2hex(length, 2)
            pb_addr_str = self.int2hex(pb_addr, 1)
            cmd = r'' + tid_str + pid_str + length + uid_str + fc_str + pb_addr_str + value
            
        return cmd.lower()      # for check letters need to be lowercase, because response of the slave only contains lowercase letters
    
    def request(self, cmd):
        """requests a certain value"""
        self._com.send(cmd)
    
    def request_echo(self, cmd):
        """sends a command and waits for the answer"""
        self.request(cmd)
        return self._com.recv()
     
    def check(self, expected):
        """checks if response is like expected"""
        response = self._com.recv()
        if expected == response:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the command went wrong. ", response, " != ", expected)
                sys.stdout.flush()
            if self._exception_on_error is True:
                raise AssertionError("A check went wrong")
            else:            
                return False  
            
    def get_value(self, response):
        """
        @brief converts received value (hex string) to integer
        @param response: received hex string
        @return value: received value as integer
        """
        pb_value = self.hex2int(response[18:])     # value of requested PB command (last 4 bytes of response)
        return pb_value
    
    def get_bulk_values(self, response):
        """
        @brief take received answer (hex string) into pieces of PB bulk command values and converts them to integer
        @param response: received hex string
        @return values: array of received PB bulk command values as integers
        """
        # configured PB bulk commands: 0x00, 0x01, 0x03, 0x05, 0x06, 0x07, 0x0a, 0x13, 0x14, 0x1b, 0x1c
        # every value has a length of 4 bytes
        val_0x00 = self.hex2int(response[18:26])    # value of PB command 0x00 --> setpoint temperature
        val_0x01 = self.hex2int(response[26:34])    # value of PB command 0x01 --> intern temperature
        val_0x03 = self.hex2int(response[34:42])    # value of PB command 0x03 --> pump pressure
        val_0x05 = self.hex2int(response[42:50])    # value of PB command 0x05 --> ERROR number of first occurred error
        val_0x06 = self.hex2int(response[50:58])    # value of PB command 0x06 --> number of last warning
        val_0x07 = self.hex2int(response[58:66])    # value of PB command 0x07 --> process temperature
        val_0x0a = self.hex2int(response[66:74])    # value of PB command 0x0a --> status of thermostat
        val_0x13 = self.hex2int(response[74:82])    # value of PB command 0x13 --> tempering mode
        val_0x14 = self.hex2int(response[82:90])    # value of PB command 0x14 --> tempering active?
        val_0x1b = self.hex2int(response[90:98])    # value of PB command 0x1b --> serial number (low bytes)
        val_0x1c = self.hex2int(response[98:])      # value of PB command 0x1c --> serial number (high bytes)
        pb_values = [val_0x00, val_0x01, val_0x03, val_0x05, val_0x06, val_0x07, val_0x0a, val_0x13, val_0x14, val_0x1b, val_0x1c]
        return pb_values
    
    def get_ex_data(self, response):
        """
        @brief converts the length and the received exception PDU to integer
        @param response: the received hex string
        @return data: array of [recv_length, recv_ex_fc, recv_ex_code]
        """  
        recv_length = self.hex2int(response[8:12])
        # see communication manual, error handling (11.3 on page 39)
        # received exception fc == sent fc + 0x80
        recv_ex_fc = self.hex2int(response[14:16], signed=False)   # must be unsigned to compare in is_exception_response() if == fc + 0x80 
        recv_ex_code = self.hex2int(response[16:]) 
        recv_data = [recv_length, recv_ex_fc, recv_ex_code]
        return recv_data
    
    def manipulate_length(self, cmd, length_new):
        """
        @brief manipulate the commands length attribute by overwriting the length with a wrong value
        @return cmd_new: the manipulated command
        """
        cmd_manipulated = cmd.replace(cmd[8:12], self.int2hex(length_new, 2))
        return cmd_manipulated


class MbFunc:
    @staticmethod
    def get_read_only_value():
        """huber-defined function to Read Only a PB command value"""
        return 0x7FFFFFFF
    
    @staticmethod   
    def get_fc_communication_test():
        """get fc for Communication Test"""
        return 0x41
    
    @staticmethod     
    def get_fc_read_single_pb():
        """get fc to Read Single PB command value"""
        return 0x42
    
    @staticmethod
    def get_fc_write_read_single_pb():
        """get fc to Write & Read Single PB command value"""
        return 0x43
    
    @staticmethod
    def get_fc_read_bulk_pb():
        """get fc to Read Bulk PB command values"""
        return 0x44
    
    @staticmethod
    def get_fc_write_read_bulk_pb():
        """get fc to Write & Read Bulk PB command values"""
        return 0x45
    
    @staticmethod
    def get_ex_invalid_function():
        """get ERROR code for Invalid fc"""
        return 0x01
    
    @staticmethod
    def get_ex_invalid_data_value():
        """get ERROR code for Invalid data value (incorrect length or number of PB bulk commands)"""
        return 0x03
    
    @staticmethod
    def get_ex_slave_device_failure():
        """get ERROR code for Slave Device Failure"""
        return 0x04
    
    @staticmethod
    def is_exception_response(function_code, received_data, exception_code):
        """
        @brief checks if the response is and exception response for a given fc or ERROR code
        @param function_code: origin/sent fc
        @param received_data: received data array to compare ([recv_length, recv_ex_fc, recv_ex_code])
        @param exception_code: configured ERROR code
        @return True if it's an exception response
        """
        # length of exception response always == 3 bytes (len(uid) + len(recv_ex_fc) + len(recv_ex_code) = 1 byte + 1 byte + 1 byte)
        if received_data[0] != 3:
            False
        # if exception, the response_fc == sent_fc + 0x80
        if received_data[1] != (function_code + 0x80):
            False
        # if exception, pb_value == exception_code  
        if received_data[2] != exception_code:
            False 
            
        return True
