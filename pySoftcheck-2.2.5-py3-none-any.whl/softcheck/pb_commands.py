#!/usr/bin/env python3

'''
Created on 28.10.2013

@author: jm
'''
 
import sys
from softcheck.logic import Com
from softcheck.logic import ComBase
from softcheck.conversion import Hex
import re


class PbCom(ComBase):
    """class for handling PB commands"""

    def __init__(self, com, verbose_level=1, exception_on_error=True):
        """
        @brief constructor for MbCom object
        @param com: Com object that has to be used for communication with the interface
        @param verbose_level: explains what is done:
                                '1': explains what went wrong in case of an error
                                '2': prints the sent and received string on the console
                                '3': prints the time on sending and receiving strings also
        @param exception_on_error: if an error occurs, should the program terminate/throw an exception? 
        """
        ComBase.__init__(self)        
        self._exception_on_error = exception_on_error
        self._verbose_level = verbose_level
        if isinstance(com, Com):
            self._com = com
        else:
            raise TypeError("The given object is not a Com object. You must provide a Com object that controls the interface")
             
    def _handle_error(self, expression, s):
        """
        @brief defines what to do in case of an error
        @param expression: the request that went wrong
        @param s: the received answer
        """        
        if self._verbose_level >= 1:
            print("ATTENTION: Request for: ", expression, "went wrong. Received Answer was: ", s)
            sys.stdout.flush()
        if self._exception_on_error is True:
            raise AssertionError("A check went wrong")
        else:
            return False

    @staticmethod
    def int2hexstr(val, bytes_used):   
        """
        @brief converts the value of an PB command to hex string
        @param val: integer to convert
        @param bytes_used: number of bits used for conversion to int
        @return string with hex value
        """     
        val_str = Hex.int2hex(val, bytes_used * 8)
        val_str = val_str[2:]
        non_hex = re.compile(r"[0-9a-fA-F]+")
        val_str = non_hex.search(val_str).group()
        val_str = val_str.zfill(2 * bytes_used)
        return val_str.upper()


    @staticmethod
    def _str2val(hex_str):
        """
        @brief converts a PB command value (hex string) to int considering the bit length
        @param hex_str: string with hex value 
        @return converted integer
        """
        return Hex.hex2int(hex_str, 16)
   
    def _msg_getval(self, cmd):
        """returns the value of a PB command"""
        s = self._com.recv()
        command = self.int2hexstr(cmd, 1)
        expression = r"{S" + command + "([0-9a-fA-F]{4})\r\n"
        result = re.match(expression, s)
        if result is not None:
            return self._str2val(result.group(1))        
        else:
            return self._handle_error(expression, s)

    def check(self, command, check):
        """
        @brief checks if the value of PB command is like expected
        @param command: command to check
        @param check: expected value
        @return True if ok; False if not
        """
        val = self._msg_getval(command) 
        if val == check:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the value went wrong. ", val, " != ", check)
                if val == 32767 :
                    print("E-Grade missing?")
                sys.stdout.flush()
            if self._exception_on_error is True:
                raise AssertionError("A check went wrong")
            else:
                return False
       
    def check_range(self, command, minimum, maximum):
        """
        @brief checks if the value of PB command is within the expected range
        @param command: command to check
        @param minimum: minimal allowed value
        @param maximum: maximal allowed value
        @return True if ok; False if not
        """
        val = self._msg_getval(command)
        if minimum <= val <= maximum:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the range went wrong. The value: ", val, "is not within (", minimum, "/", maximum, ")")
                if val == 32767 :
                    print("E-Grade missing?")
                sys.stdout.flush()
            if self._exception_on_error is True:
                raise AssertionError("A check went wrong")
            else:
                return False
      
    def send(self, cmd, value):
        """sends a PB command with a certain value"""
        string = self.int2hexstr(value, 2)
        command = self.int2hexstr(cmd, 1)
        cmd_str = r"{M" + command + string + "\r\n"
        self._com.send(cmd_str)
        
    def request(self, cmd):
        """requests a certain value"""
        command = self.int2hexstr(cmd, 1)
        cmd = r"{M" + command + "****\r\n"
        self._com.send(cmd)
          
    def request_echo(self, command):
        """sends a command and awaits the answer"""
        self.request(command)
        return self._msg_getval(command)
    
    def _ext_bit(bit_nr, val):
        """returns the value (0 or 1) of a given bit position"""
        return (val & (1 << bit_nr)) >> bit_nr
    
    _ext_bit = staticmethod(_ext_bit)
        
    def get_bit(self, cmd, bit_nr):
        """requests the value (0 or 1) of a given bit position"""
        val = self.request_echo(cmd)
        val = val & (1 << bit_nr)
        return val >> bit_nr    

    def set_bit_echo(self, cmd, bit_nr):
        """sets a bit to 1 on a given bit position (and sends the command)"""
        val = self.request_echo(cmd)
        val = val | (1 << bit_nr)
        self.send(cmd, val)
        val = self._msg_getval(cmd)
        return self._ext_bit(bit_nr, val)

    def clear_bit(self, cmd, bit_nr):
        """clears a bit to 0 on a given bit position (and sends the command)"""
        val = self.request_echo(cmd)
        val = val & (~(1 << bit_nr))
        self.send(cmd, val)
        val = self._msg_getval(cmd)
        return self._ext_bit(bit_nr, val)

