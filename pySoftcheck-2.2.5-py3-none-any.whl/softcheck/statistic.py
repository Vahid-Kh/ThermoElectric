#!/usr/bin/env python3

'''
Created on 31.10.2013

@author: jm
'''

import time
from collections import deque
import math


class StdDeviation(deque):
    """class for calculation of standard deviation"""
    def __init__(self, size = 20):
        super(StdDeviation, self).__init__(maxlen = size)
    """
    @brief calculates the std deviation of the runtimes of a command
    @param avg the average value to be able to calculate the std deviation 
    @return the standard deviation 
    """       
    def get_std_deviation(self, avg):
        sum_ = 0
        for i in range(len(self)):
            sum_ += math.pow((self[i] - avg), 2)
        if len(self) != 1:  # division by zero protection
            sum_ = sum_ /(len(self) - 1)
        return math.sqrt(sum_)


class ComStatistic(object):
    """class that collects statistics about the communication with a device"""
    
    def __init__(self):
        self._timestamp = 0
        self._runtime = 0
        self._nr_answers = 0    # the number of answers from the remote
        self._runtime_avg = 0
        self._runtime_max = 0
        self._runtime_min = 0
        self._nr_cmds_sent = 0  # the number of commands sent
        self._std_dev = StdDeviation(100)

    def start_timer(self):
        """start internal timer to measure the runtime until it receives the answer"""
        self._runtime = 0
        self._nr_cmds_sent += 1
        self._timestamp = time.time()
        
    def stop_timer(self):
        """stops the timer"""   
        time_now = time.time()
        self._runtime = time_now - self._timestamp
        # if it hasn't run before
        if self._nr_answers == 0:
            self._runtime_min = self._runtime
            self._runtime_avg = self._runtime
            self._runtime_max = self._runtime
        # update min        
        if self._runtime_min > self._runtime:
            self._runtime_min = self._runtime
        # update max
        if self._runtime_max < self._runtime:
            self._runtime_max = self._runtime
        # calculate the average speed
        nr_cmds_local = 10000000
        if self._nr_answers < 10000000:
            nr_cmds_local = self._nr_answers        
        absolue_time = nr_cmds_local * self._runtime_avg
        self._runtime_avg = (absolue_time + self._runtime) / (nr_cmds_local + 1)
        # set std deviation
        self._std_dev.append(self._runtime)        
        # increment number of commands        
        self._nr_answers += 1
                
    def get_runtime(self):
        """returns runtime of the last received command"""
        return self._runtime
    
    def get_max_runtime(self):
        """returns the maximal runtime of all commands"""
        return self._runtime_max

    def get_min_runtime(self):
        """returns the minimal runtime of all commands"""
        return self._runtime_min
    
    def get_avg_runtime(self):
        """returns the average runtime of all commands"""
        return self._runtime_avg
    
    def get_nr_cmds_sent(self):
        """returns the number of sent commands"""
        return self._nr_cmds_sent
    
    def get_nr_answers(self):
        """returns the number of received answers"""
        return self._nr_answers
    
    def get_std_deviation(self):
        """returns the std deviation of runtime"""
        return self._std_dev.get_std_deviation(self._runtime_avg)
