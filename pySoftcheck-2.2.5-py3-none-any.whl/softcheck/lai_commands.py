#!/usr/bin/env python3

"""
Created on 28.10.2013

@author: jm
"""
 
from softcheck.logic import Com
from softcheck.logic import ComBase
from softcheck.conversion import Hex
import re
import sys


class LaiCom(ComBase):
    """class for handling LAI commands"""

    def __init__(self, com, slave_address, verbose_level=1, exception_on_error=True):
        """
        @brief constructor for LaiCom object
        @param com: Com object that has to be used for communication with the interface
        @param verbose_level: explains what is done:
                                '1': explains what went wrong in case of an error
                                '2': prints the sent and received string on the console
                                '3': prints the time on sending and receiving strings also
        @param exception_on_error: if an error occurs, should the program terminate/throw an exception? 
        """
        ComBase.__init__(self)        
        self._exception_on_error = exception_on_error
        self._verbose_level = verbose_level
        self._slave_address = slave_address
        if isinstance(com, Com):
            self._com = com
        else:
            raise TypeError('''The given object is not a Com object. You must provide a Com object 
            that controls the interface''')
        
        self._cmd_id = ""
        self._last_value = ""
        
    def _handle_error(self, expression, s):
        """
        @brief defines what to do in case of an error
        @param expression: the request that went wrong
        @param s: the received answer
        """
        if self._verbose_level >= 1:
            print("ATTENTION: Request for: ", expression, "went wrong. Received Answer was: ", s)
            sys.stdout.flush()
        if self._exception_on_error:
            raise AssertionError("A check went wrong")
        else:
            return False
    
    @staticmethod
    def int2hex(value, nr_bytes):
        """converts a value to a LAI hex string (without 0x and leading zeros)"""
        if type(value) is not int:
            raise TypeError("value must be an integer")
        string = Hex.int2hex(value, nr_bytes * 8)
        string = string[2:]
        length = len(string)
        len_to_add = (nr_bytes * 2) - length
        if len_to_add < 0:
            len_to_add = 0
        for i in range(0, len_to_add):  # IGNORE:W0612
            string = "0" + string
        
        return str.upper(string)
    
    @staticmethod
    def hex2int(string, signed=True):
        """converts a LAI hex string (value) to an integer"""
        if type(string) is not str:
            raise TypeError("string must be a string")
        value = Hex.hex2int(string, len(string) * 4, signed)    # (len(string) / 2 * 8)
            
        return value
    
    def _get_slave_addr_str(self):
        """gets the slave address in LAI string form"""
        return "%02d" % self._slave_address 

    def _len_lai(self, value):  # IGNORE:R0201
        """returns the length for a LAI command if value is given"""
        hex_len = self.int2hex(len(value) + 6 + len(self._cmd_id), 1)
        return str.upper(hex_len)

    def _calculate_checksum_str(self, string):  # IGNORE:R0201
        """calculates the LAI checksum (hex string)"""
        string = self.int2hex(self._calculate_checksum(string), 1)
        return str.upper(string) 

    @staticmethod
    def _calculate_checksum(string):
        """calculates LAI checksum (int)"""
        x = 0
        for i in string:
            x += ord(i)

        return x 
   
    def send(self, cmd, value=""):
        """sends a LAI command with a certain value"""
        if (type(value) is not str) or (type(cmd) is not str):
            raise TypeError("The value and command of a LAI command must be a string!")
        self._cmd_id = cmd
        cmd_without_checksum = r"[M" + self._get_slave_addr_str() + cmd + self._len_lai(value) + value 
        self._calculate_checksum_str(cmd_without_checksum)
        cmd_str = r"" + cmd_without_checksum + self._calculate_checksum_str(cmd_without_checksum) + "\r"
        self._com.send(cmd_str)

    def _msg_getval(self):
        """returns the data of a LAI command and does all other checks that can be done with a LAI command"""
        s = self._com.recv()
        tmp_str = "[S" + self._get_slave_addr_str() + self._cmd_id
        tmp_str = re.escape(tmp_str)
        expression = r"" + tmp_str + "([0-9A-F]{2})([ 0-9a-zA-Z-+_.]*)([0-9A-F]{2})\r"
        result = re.match(expression, s)
        if result is None:
            self._handle_error(expression, s)
            return ""
        
        length = result.group(1)
        string = result.group(2)
        checksum = result.group(3)
        length_int = self.hex2int(length)
        str_without_checksum = s[:-3]
        
        if len(str_without_checksum) != length_int:
            self._handle_error(expression, s)
            return ""
        if checksum != self._calculate_checksum_str(str_without_checksum):
            self._handle_error(expression, s)
            return ""
        self._last_value = string
        
        return string  
   
    def check(self, str2check):
        """
        @brief checks if the value of a LAI command is like expected
        @param str2check: expected value
        @return True if ok; False if not
        """
        val = self._msg_getval() 
        if val == str2check:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the value went wrong. ", val, " != ", str2check,
                      "in command: ", self._cmd_id)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False
  
    def check_regex(self, regex):
        """
        @brief checks if the value of a LAI command is like expected with a regex
        @param regex: does the parsing
        @return True if ok; False if not
        """        
        val = self._msg_getval() 
        if re.match(regex, val) is not None:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the value went wrong. ", val, " does not match the regex ", regex,
                      "in command: ", self._cmd_id)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False
        
    def check_hex(self, hex_string, int_value):
        """
        @brief checks if the hex value (string) of a LAI command is like expected
        @param hex_string: hex value (part of LAI command) to check
        @param int_value: int value to compare against hex_string
        @return True if ok; False if not
        """ 
        if (type(hex_string) is not str) or (type(int_value) is not int):
            raise TypeError('''The type of hex_string must be a hex string (without \'0x\' in front)  
                                 and  int_value must be the int value to check against!''')
        hex_val = self.hex2int(hex_string)
        if hex_val == int_value:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the value went wrong. ", hex_val, " != ", int_value,
                      "in command: ", self._cmd_id)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False
      
    def check_hex_range(self, hex_string, minimum, maximum):
        """
        @brief checks if the hex value (string) of a LAI command is in the range expected
        @param hex_string: hex value (part of LAI command) to check
        @param minimum: minimal int value allowed
        @param maximum: maximal int value allowed
        @return True if ok; False if not
        """ 
        if (type(hex_string) is not str) or (type(minimum) is not int) or (type(maximum) is not int):
            raise TypeError('''The type of hex_string must be a hex string (without \'0x\' in front)  
                                 and  minimum and maximum must be int values that define the range!''')
        hex_val = self.hex2int(hex_string)
        if minimum <= hex_val <= maximum:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: checking the range went wrong. The value: ", hex_val,
                      "is not within (", minimum, "/", maximum, ") in command: ", self._cmd_id)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False

    def get_last_value(self):
        """returns the last received value"""
        return self._last_value
       
    def change_to(self, cmd, value):
        """changes the command/value pair given and ensures that set correctly """
        self.send(cmd, value)
        return self.check(value)
        
    def request_echo(self, command, value=""):
        """sends a command and waits for the answer"""
        self.send(command, value)
        return self._msg_getval()
