#!/usr/bin/env python3

"""
Created on 28.10.2013

@author: jm
"""


class Hex(object):
    """class for handling hex values (strings and integers"""

    @staticmethod
    def hex2int(val_str, bits, signed=True):
        """converts hex string to an integer value"""
        val = int(val_str, 16)
        if signed is True:
            if (val & (1 << (bits - 1))) != 0:
                val = val - (1 << bits)
        return val

    @staticmethod
    def int2hex(val, bits):
        """converts integer value to hex string"""
        return hex((val + (1 << bits)) % (1 << bits))
    

