#!/usr/bin/env python3

'''
Created on 17.02.2014

@author: cro
'''
import sys

__version__ = "1.36"                      # moduleversion_concat
__PYSOFTCHECK_SW_ID__ = 122              # sw_version_sw_id
__PYSOFTCHECK_SW_GENNR__ =  1            #sw_version_sw_gen_nr
__PYSOFTCHECK_SW_YEAR__ = 2023           # sw_version_sw_year
__PYSOFTCHECK_SW_MONTH__ = 4            # sw_version_sw_month
__PYSOFTCHECK_SW_DAY__ = 25              # sw_version_sw_day
__PYSOFTCHECK_SW_INDEX__ = 0             # sw_version_sw_index
__PYSOFTCHECK_SW_INDEX__T__= -1          # sw_version_sw_T_index
__PYSOFTCHECK_SW_INDEX__R__ = 0          # sw_version_sw_R_index
__PYSOFTCHECK_SW_RELEASE_INFO__= "R"     # sw_version_sw_release_info
__PYSOFTCHECK_SW_BUILD_NR__ = 59         # sw_version_sw_build_nr

class Version:
    def __init__(self):
        return

    @staticmethod
    def print_version(print_and_exit):
        """print version and exit script"""
        if print_and_exit:
            print(__version__)
            sys.exit(0)