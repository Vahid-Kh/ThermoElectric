#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
 Created on 24.12.2009

@author: jo
"""

import binascii
import datetime
import queue
import re
import select
import socket
import sys
import threading
import time
import serial
from serial.serialutil import SerialException
from softcheck.statistic import ComStatistic


class ComBase(object):
    """base class for all communication classes"""

    def __init__(self):
        self._assert_errors = 0

    def get_nr_faulty_answers(self):
        """returns the number of assert errors occurred since initialization"""
        return self._assert_errors


class CommunicationTimeout(Exception):
    """exception class to indicate a communication timeout"""

    def __str__(self):
        return "Communication timeout"


class Com(ComBase):
    """class for saving settings of the different interfaces"""

    def __init__(self, interface="serial", timeout=1, verbose_level=1, exception_on_error=True):
        """
        @brief constructor for Com object
        @param interface: 'serial', 'ethernet' or 'modbustcp'
        @param timeout: for used interface specified timeout 
        @param verbose_level: explains what is done:
                                '1': explains what went wrong in case of an error
                                '2': prints the sent and received string on the console
                                '3': prints the time on sending and receiving strings also
        @param exception_on_error: if an error occurs, should the program terminate/throw an exception? 
        """
        ComBase.__init__(self)
        self._isSerial = False
        self._isEthernet = False
        self._isModbusTCP = False
        self._timeout = timeout
        self._exception_on_error = exception_on_error
        self._verbose_level = verbose_level
        self._stat = ComStatistic()  # statistic class for communication
        self._assert_errors = 0
        self._nr_timeouts = 0
        self._end_n = False
        self._time_start = time.time()

        if interface == "serial":
            self._isSerial = True
        if interface == "ethernet":
            self._isEthernet = True
        if interface == "modbustcp":
            self._isModbusTCP = True

        if self._isSerial:
            # initialize ser
            self._ser = serial.Serial()
            self._isSerial = True
        elif self._isModbusTCP:
            # initialize sock
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._isModbusTCP = True
        else:
            # initialize sock
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._isEthernet = True

    def __del__(self):
        """destructor for Com object"""
        if self._isSerial:
            self._ser.close()  # close serial interface
        if self._isEthernet or self._isModbusTCP:
            self._sock.close()  # close socket

    def _print_verbose_string(self, direction_str, message):
        """
        @brief prints strings on the console according to the verbosity level
        @param direction_str: string that marks the direction e.g. 'sending'
        @param message: what to print on the console
        """
        if self._verbose_level < 2:
            return
        verbose_str = ""
        if self._verbose_level >= 2:
            verbose_str = direction_str + ": " + message
        if self._verbose_level >= 3:
            timestamp = time.time() - self._time_start
            verbose_str = "%.3f  " % timestamp + verbose_str
        if self._verbose_level >= 2:
            print(verbose_str.encode(errors="string-escape"))
            sys.stdout.flush()

    def send(self, message):
        """
        @brief encodes message string to bytes and sends it over the interface 
        @param message: the command to send 
        """
        # start timer for statistic object
        self._stat.start_timer()
        if message.endswith('\n'):
            self._end_n = True
        else:
            self._end_n = False
        self._print_verbose_string("send", message)
        if self._isSerial:
            self._ser.reset_input_buffer()  # clear input buffer
            self._ser.write(message.encode())  # sends encoded command

        if self._isEthernet:
            i, o, e = select.select([self._sock], [], [], 0)
            while len(i):
                self._sock.recv(1024)
                i, o, e = select.select([self._sock], [], [], 0)
            self._sock.send(message.encode())  # sends encoded command

        if self._isModbusTCP:
            message = bytes.fromhex(message)  # converts hex-string to bytes object
            self._sock.send(message)

    def check(self, expression):
        """
        @brief checks the content of the received answer
        @param expression: regular expression that must match with the content
        @return True if it matches; if not False
        """
        string = self.recv()
        if re.match(re.escape(expression), string) is not None:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: Request for: ", expression, "went wrong. Received Answer was: ", string)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False

    def check_regex(self, expression):
        """
        @brief checks the content of the received answer with regex
        @param expression: regular expression that must match with the content
        @return True if it matches; if not False
        """
        string = self.recv()
        if re.match(expression, string) is not None:
            return True
        else:
            self._assert_errors += 1
            if self._verbose_level >= 1:
                print("ATTENTION: Request for: ", expression, "went wrong. Received Answer was: ", string)
                sys.stdout.flush()
            if self._exception_on_error:
                raise AssertionError("A check went wrong")
            else:
                return False

    def print_answer(self):
        """prints the received answer"""
        print(self.recv())
        sys.stdout.flush()

    def recv(self):
        """
        @brief receives answer over the interface as bytes and decodes it to string 
        @return string: received answer as string
        """
        string = ""
        if self._isSerial:
            try:
                if self._end_n:
                    string = self._ser.readline()
                else:
                    string = self._ser.read_until(terminator=b'\r')
                string = string.decode()
                # check if reading has been terminated on timeout
                if string == "":
                    raise CommunicationTimeout
                # stop timer for statistic object
                self._stat.stop_timer()
            except:
                self._nr_timeouts += 1
                if self._verbose_level >= 1:
                    print("Timeout occurred")
                    sys.stdout.flush()
                if self._exception_on_error:
                    raise CommunicationTimeout("Timeout while receiving")

        if self._isEthernet:
            try:
                string = self._sock.recv(1024)
                string = string.decode()  # decodes received bytes to string
                i, o, e = select.select([self._sock], [], [], 0)
                while len(i):
                    string.append(self._sock.recv(1024))
                    i, o, e = select.select([self._sock], [], [], 0)
                # stop timer for statistic object
                self._stat.stop_timer()
            except (KeyboardInterrupt, SystemExit):
                self.close()
                raise KeyboardInterrupt("Program aborted upon user request")
            except:
                self._nr_timeouts += 1
                if self._verbose_level >= 1:
                    print("Timeout occurred")
                    sys.stdout.flush()
                if self._exception_on_error:
                    raise CommunicationTimeout("Timeout while receiving")

        if self._isModbusTCP:
            try:
                string = self._sock.recv(1024)
                string = binascii.hexlify(string)
                string = string.decode()
                # stop timer for statistic object
                self._stat.stop_timer()
            except (KeyboardInterrupt, SystemExit):
                self.close()
                raise KeyboardInterrupt("Program aborted upon user request")
            except:
                self._nr_timeouts += 1
                if self._verbose_level >= 1:
                    print("Timeout occurred")
                    sys.stdout.flush()
                if self._exception_on_error:
                    raise CommunicationTimeout("Timeout while receiving")

        self._print_verbose_string("received", string)
        return string

    def open(self, first, second=None):
        """
        @brief opens a specified interface ('serial', 'ethernet' or  'modbustcp')
        @param first:   'serial': communication port; ATTENTION COM1 = 0, COM2 = 1, ...
                        'ethernet'/'modbustcp': IP-address
        @param second:  'serial': baudrate
                        'ethernet': communication port (8101)
                        'modbustcp': communication port (502)
        """
        if self._isSerial:
            self._ser.baudrate = second
            self._ser.port = first
            self._ser.timeout = self._timeout
            try:
                self._ser.open()
            except SerialException:
                if self._verbose_level >= 1:
                    print("Either port is already open or does not exist.")
                    sys.stdout.flush()
                return False

        if self._isEthernet or self._isModbusTCP:
            self._sock.settimeout(self._timeout)
            self._sock.connect((first, second))

        return True

    def set_timeout(self, timeout):
        """sets the timeout of the used interface"""
        self._timeout = timeout

        if self._isSerial:
            if self._ser.isOpen():
                self._ser.close()
                self._ser.timeout = self._timeout
                self._ser.open()

        if self._isEthernet or self._isModbusTCP:
            self._sock.settimeout(self._timeout)

    def close(self):
        """closes the interface"""
        if self._isSerial:
            self._ser.close()
        if self._isEthernet or self._isModbusTCP:
            self._sock.close()

    def store_answer(self, com_store_object):
        """stores the received string in a file"""
        com_store_object.store(self.recv())

    @staticmethod
    def store_string(com_store_object, string):  # IGNORE:R0201
        """stores the given string in a file"""
        com_store_object.store(string)

    def get_runtime(self):
        """returns the runtime of the last command that has been received"""
        return self._stat.get_runtime()

    def get_max_runtime(self):
        """returns the maximal runtime of all commands"""
        return self._stat.get_max_runtime()

    def get_min_runtime(self):
        """returns the minimal runtime of all commands"""
        return self._stat.get_min_runtime()

    def get_avg_runtime(self):
        """returns the average runtime of all commands"""
        return self._stat.get_avg_runtime()

    def get_nr_cmds_sent(self):
        """returns the number of commands sent"""
        return self._stat.get_nr_cmds_sent()

    def get_nr_answers(self):
        """returns the number of received answers"""
        return self._stat.get_nr_answers()

    def get_nr_timeouts(self):
        """returns the number of timeouts occurred"""
        return self._nr_timeouts

    def get_std_deviation(self):
        """returns the standard deviation of runtime"""
        return self._stat.get_std_deviation()

    ## returns if the interface is a serial port
    #
    # @return true if it is a serial port
    def get_is_serial(self):
        return self._isSerial

    ## returns the object of the serial class
    #
    # @return serial class object
    def get_serial(self):
        return self._ser

    ## returns the read buffer
    #
    # @return buffer object
    def get_read_buffer(self):
        return self._r_buffer

    ## returns if the interface is a ethernet port
    #
    # @return true if it is a ethernet port
    def get_is_ethernet(self):
        return self._isEthernet

    ## returns if the interface is a modbus tcp port
    #
    # @return true if it is a modbus tcp port
    def get_is_modbus(self):
        return self._isModbusTCP

    ## returns the object of the socket class
    #
    # @return socket class object
    def get_socket(self):
        return self._sock

## class for saving settings of the different interfaces            
class ComStore(object): 
    """class for saving settings of the different interfaces"""

    def __init__(self, filepath):
        self.__queue = queue.Queue()
        self.__filepath = filepath
        self.__fileobject = open(self.__filepath, "w")
        self.__timestamp_start = time.time()
        self.__write_header()
        self.__start_saving()

    def __del__(self):
        self.__write2disk()
        self.__fileobject.close()

    def __write_header(self):
        """writes the header of the current file"""
        date = datetime.datetime.now()
        self.__queue.put("[DATE];" + date.strftime("%d.%m.%Y") + "\r")
        self.__queue.put("[TIME];" + date.strftime("%H:%M:%S") + "\r\r")
        self.__queue.put("[DATA];time;str" + "\r\r")

    def __write2disk(self):
        """writes buffer to disk"""
        answers = []
        while not self.__queue.empty():
            answer = self.__queue.get()
            answers.append(answer)
        self.__fileobject.writelines(answers)
        self.__fileobject.flush()

    def __start_saving(self):
        """starts a timer that flushes the disk cash periodically"""
        self.__write2disk()
        timer = threading.Timer(30, self.__start_saving)
        timer.daemon = True
        timer.start()

    def store(self, string2store):
        """stores a string in the internal buffer and saves it later to disk"""
        if "\r" not in string2store:
            string2store = string2store + "\r"
        # add date format
        secs = time.time() - self.__timestamp_start
        string2store = ";%.1f;%s" % (secs, string2store)
        self.__queue.put(string2store)
